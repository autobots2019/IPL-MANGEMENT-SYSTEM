export class Team{
    teamId:number;
    teamName:string;   
}