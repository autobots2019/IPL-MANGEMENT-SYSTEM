import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Playeredit1Component } from './playeredit1.component';

describe('Playeredit1Component', () => {
  let component: Playeredit1Component;
  let fixture: ComponentFixture<Playeredit1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Playeredit1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Playeredit1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
