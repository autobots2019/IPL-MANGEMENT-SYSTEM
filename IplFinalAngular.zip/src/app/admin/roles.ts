export class Roles{
    id:number;
    rolename:string;
}