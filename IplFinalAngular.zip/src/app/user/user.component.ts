import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Team } from '../pm/team';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  owners: Object;
  errorMessage: string
  team:Team=new Team();
  

  constructor(private userService: UserService,router:Router) { }

  ngOnInit() {
    this.userService.getUserBoard().subscribe(
      data => {
        this.owners = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );

    this.userService.getTeamBoard1().subscribe(
      data => {
        this.team = data;
      }
    )
  }
}
