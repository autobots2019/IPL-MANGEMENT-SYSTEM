import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Team } from '../pm/team';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private userPlayerUrl = 'http://localhost:8080/api/players/all';
  private userUrl1 = 'http://localhost:8080/api/players/user/playerregister';
  private userUrl = 'http://localhost:8080/api/players/user';
  private usersAdminUrl = 'http://localhost:8080/api/admin/users/all';
  private pmUrl = 'http://localhost:8080/api/test/pm';
  private pmTeamUrl = 'http://localhost:8080/api/test/pm/teamregistered';
  private adminUrl = 'http://localhost:8080/api/test/admin';
  private pmUserUrl = 'http://localhost:8080/api/players/all';
  private pmPlayerRole = 'http://localhost:8080/api/players/user';
  private ownersUrl='http://localhost:8080/api/owners/pm';
  private rolesAdminUrl='http://localhost:8080/api/admin/roles/all';
  private rolesregister='http://localhost:8080/api/admin/roles/adminregisterroles';
  private pmUrlDelete = 'http://localhost:8080/api/owners/pm';
  private adminDeleteTeam='http://localhost:8080/api/test/pm';

  constructor(private http: HttpClient) { }

  getOwnersBoard(): Observable<Object> {
    return this.http.get(this.ownersUrl, { responseType: 'json' });
  }

  getPmUserBoard(): Observable<Object> {
    return this.http.get(this.pmUserUrl, { responseType: 'json' });
  }

  getAdminUsersBoard1(): Observable<any> {
    return this.http.get(this.usersAdminUrl, { responseType: 'json' });
  }

  getUserBoard(): Observable<Object> {
    return this.http.get(this.userUrl, { responseType: 'json' });
  }
  getOwnerBoard(): Observable<Object> {
    return this.http.get(this.pmUrl, { responseType: 'json' });
  }


  getPMBoard(): Observable<string> {
    return this.http.get(this.pmUrl, { responseType: 'text' });
  }

  getAdminBoard(): Observable<Object> {
    return this.http.get(this.adminUrl, { responseType: 'json' });
  }
  
  getTeamList():Observable<any>{
    return this.http.get(`${this.adminUrl}`);
  }

  createPlayer(player: Object): Observable<Object> {
    return this.http.post(this.userUrl1+`/create`, player);
     }
  
  acceptPlayer(players:Object): Observable<Object> {
    console.dir(players);
    return this.http.post(this.pmUrl+`/accept`, players);
  }

  deletePlayer(playerId: any): Observable<Object> {
    console.log(`${this.pmUrlDelete}/delete/${playerId}`);
    return this.http.delete(`${this.pmUrlDelete}/delete/${playerId}`);
  }
  
updatePlayer(id: number,value:any): Observable<Object> {
  return this.http.put(`${this.userUrl}/update/${id}`,value);
}


createTeam(team: Object): Observable<Object> {
  return this.http.post(this.pmUrl+`/createTeam`, team);
   }

   deleteTeam(teamId: any): Observable<Object> {
    console.log(`${this.pmUrlDelete}/delete/${teamId}`);
    return this.http.delete(`${this.adminDeleteTeam}/delete/${teamId}`);
  }

   getTeamBoard(): Observable<any> {
    return this.http.get(this.pmTeamUrl, { responseType: 'json' });
  }

  getTeamBoard1(): Observable<any> {
    return this.http.get(this.pmTeamUrl, { responseType: 'json' });
  }


  getPlayerBoard(): Observable<Object> {
    return this.http.get(this.userPlayerUrl, { responseType: 'json' });
  }

  updatePlayerRole(id: number,value:any): Observable<Object> {
    return this.http.put(`${this.pmPlayerRole}/updatePlayerRole/${id}`,value);
  }  

  getAdminRolesBoard(): Observable<any> {
    return this.http.get(this.rolesAdminUrl, { responseType: 'json' });
  }

  createRole(role:Object): Observable<Object> {
    console.dir(role);
    return this.http.post(this.rolesregister+`/create`, role);
  }
}
