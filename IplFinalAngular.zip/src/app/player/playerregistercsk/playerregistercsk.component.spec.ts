import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayerregistercskComponent } from './playerregistercsk.component';

describe('PlayerregistercskComponent', () => {
  let component: PlayerregistercskComponent;
  let fixture: ComponentFixture<PlayerregistercskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlayerregistercskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlayerregistercskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
