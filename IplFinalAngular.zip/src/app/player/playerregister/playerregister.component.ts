import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Player } from 'src/app/player';
import { UserService } from 'src/app/services/user.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-playerregister',
  templateUrl: './playerregister.component.html',
  styleUrls: ['./playerregister.component.css']
})
export class PlayerregisterComponent implements OnInit {

  player: Player=new Player();
  submitted = false;

  board: any;
  errorMessage: string;
  angForm:FormGroup;

  // constructor(private userService: UserService,private router:Router, ) { }
  constructor(private fb: FormBuilder,private userService: UserService,private router:Router) { 
    this.createForm();
  }

  ngOnInit() {
    this.userService.getUserBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );
  }

  

 createForm(){
  this.angForm=this.fb.group({
   
    playerName:['',Validators.required],
    dateOfBirth:['',Validators.required],
    playerAddress:['',Validators.required],
    mobileNo:['',Validators.required],
    email:['',Validators.required],
    matchesPlayed:['',Validators.required],
    playerRole:['',Validators.required],
    majorTeams:['',Validators.required],
    strikeRate:['',Validators.required],
    average:['',Validators.required],
    experience:['',Validators.required],
    playerRank:['',Validators.required],
  selectedTeam:['',Validators.required]
  });
}

  newPlayer():void{
    this.submitted=false;
    this.player = new Player();
  }

  save(){
    if(!this.submitted){
      this.userService.createPlayer(this.player).subscribe(player => {
        console.log(player);
        this.submitted = false;
      },
      error => {
        console.log(error);
        this.submitted = false;
      });
    }
  }

  submit(){
    this.save();
    this.submitted = true;
  }
}
