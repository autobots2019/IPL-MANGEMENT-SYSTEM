import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-players',
  templateUrl: './admin-players.component.html',
  styleUrls: ['./admin-players.component.css']
})
export class AdminPlayersComponent implements OnInit {

  player:Player;
  board: any;
  errorMessage: string;
  constructor(private userService: UserService,private router:Router) { }

  ngOnInit() {
    this.userService.getPlayerBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );
  }

}
