import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { Teams } from '../admin/teams';
import { Team } from '../pm/team';

@Component({
  selector: 'app-playerlist1',
  templateUrl: './playerlist1.component.html',
  styleUrls: ['./playerlist1.component.css']
})
export class Playerlist1Component implements OnInit {
  player:Player;
  board: any;
  team:Team=new Team();
  errorMessage: string;
  constructor(private userService: UserService,private router:Router) { }

  ngOnInit() {
    this.reloadData();
    this.userService.getPlayerBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );
    this.reloadData();
    this.userService.getTeamBoard().subscribe(
      data => {
        this.team = data;
      }
    )}

    deletePlayer(playerId: any) {
      this.userService.deletePlayer(playerId)
        .subscribe(
          data => {
            console.log(data);
            this.reloadData();
          },
          error => console.log(error));
    }


    reloadData(){
      this.userService.getPlayerBoard();
    }
  }

