package com.ipl.jwtauthentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.jwtauthentication.model.Owner;
import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.security.services.PlayerService;
import com.ipl.jwtauthentication.security.services.TeamDetailService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/players")
public class IPLPlayerController {
	
	@Autowired
	PlayerService playerService;
	
	
	@GetMapping("/user")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<Iterable<Player>> findAll() {
	  
	  System.out.println("in find all");
	  
	  Iterable<Player> players = playerService.findAll();
	  return ResponseEntity.ok(players);
	}
	
	
	
	@Autowired
	TeamDetailService teamsDetailService;
	

	
	@DeleteMapping("/delete/{playerId}")
	public String deleteById(@PathVariable long playerId) 
	{ 
		return playerService.deleteById(playerId);
	 }
//	@GetMapping("/owner")
//	@PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
//	public String projectManagementAccess() {
//		return ">>> Project Management Board";
//	}
//	
//	@GetMapping("/admin")
//	@PreAuthorize("hasRole('ADMIN')")
//	public String adminAccess() {
//		return ">>> Admin Contents";
//	}
	

	
}

/*
 * @GetMapping("/test/admin")
 * 
 * @PreAuthorize("hasRole('ADMIN')") public ResponseEntity<Iterable<Teams>>
 * findAll() {
 * 
 * System.out.println("in find all");
 * 
 * Iterable<Teams> teams = teamsDetailService.findAll();
 * 
 * 
 * 
 * return ResponseEntity.ok(teams); }
 */