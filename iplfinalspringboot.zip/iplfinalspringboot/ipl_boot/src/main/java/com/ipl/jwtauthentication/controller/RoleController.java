package com.ipl.jwtauthentication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.Role;
import com.ipl.jwtauthentication.model.User;
import com.ipl.jwtauthentication.security.services.RoleDetailService;
import com.ipl.jwtauthentication.security.services.UserServiceDetails;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/admin/roles")
public class RoleController {

	
	@Autowired(required=true)
	RoleDetailService roleDetailService;
	
	@GetMapping("/all")
	public List<Role> findAll(){
		List<Role> roles = roleDetailService.findAll();
		System.out.println(" ---> "+roles.size());
		return roles;
	}
	
	@PostMapping({"adminregisterroles/create"})
	public Role save(@RequestBody Role role) {
		System.out.println(role);
		return roleDetailService.save(new Role(role.getName()));
	}
}
