package com.ipl.jwtauthentication.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.Team;


@Repository
public interface IPlayerRepository extends JpaRepository<Player, Long> {
	
	List<Player> findAll();
	Player deleteById(long playerId);
	
	Player save(Player player);
	
	

	Optional<Player> findById(long playerId);
	
}
