package com.ipl.jwtauthentication.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.jwtauthentication.model.Owner;
import com.ipl.jwtauthentication.repository.OwnerRepository;
import com.ipl.jwtauthentication.security.services.PlayerService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/owners/pm")
public class OwnerController {
	
	@Autowired
	PlayerService service;
	
	
	@Autowired
	OwnerRepository repository;
	
	@GetMapping("/all")
	public List<Owner>	getAllTeams()
	{
		System.out.println("Get all owner...");
		List<Owner> owners=new ArrayList<Owner>();
		repository.findAll().forEach(owners::add);
		
		return owners;
	}
	
	@DeleteMapping("/delete/{playerId}")
	public ResponseEntity<String> deletePlayerById(@PathVariable("playerId") long playerId){
		System.out.println("deleting player -> "+playerId);
		service.deleteById(playerId);
		return ResponseEntity.ok("deleted "+playerId); 
	}

}
