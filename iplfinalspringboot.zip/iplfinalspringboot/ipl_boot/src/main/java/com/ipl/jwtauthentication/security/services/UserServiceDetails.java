package com.ipl.jwtauthentication.security.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.User;
import com.ipl.jwtauthentication.repository.IPlayerRepository;
import com.ipl.jwtauthentication.repository.UserRepository;
@Service
public class UserServiceDetails {
	@Autowired
	private UserRepository repository;
	
	public List<User> findAll(){
		return repository.findAll();
	}
}
