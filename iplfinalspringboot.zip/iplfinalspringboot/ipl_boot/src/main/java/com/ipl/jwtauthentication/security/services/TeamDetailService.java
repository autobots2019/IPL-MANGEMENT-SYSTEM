package com.ipl.jwtauthentication.security.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.Team;
import com.ipl.jwtauthentication.repository.TeamRepository;
@Service
public class TeamDetailService{

	@Autowired
	private TeamRepository repository;
	
	public List<Team> findAll(){
		return repository.findAll();
	}

	public Team save(Team teams) {
		return repository.save(teams);
	}

	
	public String deleteById(long teamId) {
		 repository.deleteById(teamId);
		return "Deleted";
	}
	
}
