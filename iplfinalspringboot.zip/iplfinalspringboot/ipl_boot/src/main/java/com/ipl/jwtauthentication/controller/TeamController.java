package com.ipl.jwtauthentication.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.Team;
import com.ipl.jwtauthentication.repository.TeamRepository;
import com.ipl.jwtauthentication.security.services.TeamDetailService;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/test/pm")
public class TeamController {
	@Autowired
	TeamDetailService teamsDetailService;
	
	
	@GetMapping("/teamregistered")
	public ResponseEntity<Iterable<Team>> findAll() {
		
		System.out.println("in find all");
		
		Iterable<Team> teams = teamsDetailService.findAll();
		
		
		return ResponseEntity.ok(teams);
	}
	
	@PostMapping({"/createTeam"})
	public Team save(@RequestBody Team team) {
		System.out.println(team);
		return teamsDetailService.save(new Team(team.getTeamId(),team.getTeamName()));
	}
	
	@DeleteMapping("/delete/{teamId}")
	public String deleteById(@PathVariable long teamId) 
	{ 
		return teamsDetailService.deleteById(teamId);
	 }
}
