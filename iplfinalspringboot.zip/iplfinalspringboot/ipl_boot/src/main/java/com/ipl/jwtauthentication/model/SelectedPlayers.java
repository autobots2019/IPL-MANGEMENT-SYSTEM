package com.ipl.jwtauthentication.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="selectedplayers")
public class SelectedPlayers {
	@Id
	private long id;
	
	private long selectedPlayerId;
	
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	Player player;

	public SelectedPlayers() {
		super();
	}

	public SelectedPlayers(long selectedPlayerId, Player player) {
		super();
		this.selectedPlayerId = selectedPlayerId;
		this.player = player;
	}

	@Override
	public String toString() {
		return "SelectedPlayers [selectedPlayerId=" + selectedPlayerId + ", player=" + player + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (selectedPlayerId ^ (selectedPlayerId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SelectedPlayers other = (SelectedPlayers) obj;
		if (selectedPlayerId != other.selectedPlayerId)
			return false;
		return true;
	}

	public long getSelectedPlayerId() {
		return selectedPlayerId;
	}

	public void setSelectedPlayerId(long selectedPlayerId) {
		this.selectedPlayerId = selectedPlayerId;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}
	
	

}
