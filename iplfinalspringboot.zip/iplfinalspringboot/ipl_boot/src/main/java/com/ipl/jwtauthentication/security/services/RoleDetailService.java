package com.ipl.jwtauthentication.security.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.Role;
import com.ipl.jwtauthentication.model.User;
import com.ipl.jwtauthentication.repository.RoleRepository;
import com.ipl.jwtauthentication.repository.UserRepository;

@Service
public class RoleDetailService {
	
	@Autowired
	private RoleRepository repository;
	
	public Role save(Role role) {
		return repository.save(role);
	}

	public List<Role> findAll() {
		return repository.findAll();
	}
}
