package com.ipl.jwtauthentication.model;

public enum  RoleName {
    ROLE_USER,
    ROLE_OWNER,
    ROLE_ADMIN
}