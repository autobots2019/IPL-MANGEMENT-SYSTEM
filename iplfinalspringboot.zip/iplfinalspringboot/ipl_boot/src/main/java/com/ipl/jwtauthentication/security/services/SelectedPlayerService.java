package com.ipl.jwtauthentication.security.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipl.jwtauthentication.model.SelectedPlayers;
import com.ipl.jwtauthentication.repository.SelectedPlayerRepository;

@Service
public class SelectedPlayerService {
	
	@Autowired
	private SelectedPlayerRepository repository;
	
	public SelectedPlayers save(SelectedPlayers selectedPlayers) {
		return repository.save(selectedPlayers);
	}	

}
